const String baseUrl = 'https://fluffypaw.azurewebsites.net/api';
