abstract class PetRemoteDataSource{

}