import 'package:fluffypawmobile/data/models/api_response.dart';
import 'package:fluffypawmobile/domain/entities/account.dart';

abstract class UserRemoteDataSource {
  Future<ApiResponse<Account>> getPetOwnerInfo();
}