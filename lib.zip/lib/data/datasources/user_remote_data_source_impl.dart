import 'package:fluffypawmobile/core/error/exceptions.dart';
import 'package:fluffypawmobile/core/utils/constants.dart';
import 'package:fluffypawmobile/data/datasources/abstract/user_remote_data_source.dart';
import 'package:fluffypawmobile/data/models/api_response.dart';
import 'package:fluffypawmobile/domain/entities/account.dart';
import 'package:http/http.dart' as http;

class UserRemoteDataSourceImpl implements UserRemoteDataSource{
  final http.Client client;

  UserRemoteDataSourceImpl({required this.client});

  @override
  Future<ApiResponse<Account>> getPetOwnerInfo() async{
    try{
      final response = await client.post(
        Uri.parse(baseUrl + "/PetOwner/GetPetOwnerDetail"),
        headers: {
          'Content-Type': 'application/json',
          'Authorization' : 'Bearer $token',
      },
      );
      
    } on http.ClientException {
      throw NetworkException(message: '');
    } catch (e){
      throw ServerException(message: e is ServerException ? e.message: '');
    }
  }

}