import 'package:fluffypawmobile/dependency_injection/dependency_injection.dart';
import 'package:fluffypawmobile/presentation/pages/loading_screen/loading_screen.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

// State notifier to manage user profile data
class UserProfileScreen extends ConsumerStatefulWidget{
  @override
  _UserProfileDetailState createState() => _UserProfileDetailState();
}

class _UserProfileDetailState extends ConsumerState<UserProfileScreen> {
  @override
  Widget build(BuildContext context) {
    final userProfileViewModel = ref.watch(userProfileViewModelProvider);
    if (userProfileViewModel.isLoading) {
      return LoadingScreen(); // Display loading screen while data is being fetched
    }

    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: Icon(Icons.arrow_back),
          onPressed: () {
            Navigator.pop(context);
            // Handle back button press
          },
        ),
        title: Text('User Profile'),
        backgroundColor: Colors.white,
        foregroundColor: Colors.black,
        elevation: 0,
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            SizedBox(height: 20),
            CircleAvatar(
              radius: 50,
              backgroundColor: Colors.grey[300],
              child: Image.network(userProfileViewModel.avatar),

              // You can add a profile image here
            ),
            SizedBox(height: 10),
            Text(
              userProfileViewModel.fullName,
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            Text(
              userProfileViewModel.email,
              textAlign: TextAlign.center,
              style: TextStyle(color: Colors.grey),
            ),
            SizedBox(height: 20),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                // _buildStatColumn('Feed', '${userProfile.feed}'),
                // _buildStatColumn('Followers', '${userProfile.followers}'),
                // _buildStatColumn('Following', '${userProfile.following}'),
              ],
            ),
            SizedBox(height: 20),
            Padding(
              padding: EdgeInsets.symmetric(horizontal: 20),
              // child: ElevatedButton(
              //   child: Text(userProfile.isFollowing ? 'Unfollow' : 'Follow'),
              //   style: ElevatedButton.styleFrom(
              //     backgroundColor: userProfile.isFollowing ? Colors.grey : Colors.deepPurple,
              //     minimumSize: Size(double.infinity, 50),
              //   ),
              //   onPressed: () {
              //     ref.read(userProfileProvider.notifier).toggleFollow();
              //   },
              // ),
            ),
            SizedBox(height: 20),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                _buildLocationChip('New York'),
                _buildLocationChip('Los Angeles'),
                _buildLocationChip('Washington'),
              ],
            ),
            SizedBox(height: 20),
            GridView.count(
              shrinkWrap: true,
              physics: NeverScrollableScrollPhysics(),
              crossAxisCount: 2,
              children: List.generate(4, (index) {
                return Card(
                  color: Colors.grey[300],
                  margin: EdgeInsets.all(8),
                );
              }),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildStatColumn(String title, String count) {
    return Column(
      children: [
        Text(
          count,
          style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
        ),
        Text(
          title,
          style: TextStyle(color: Colors.grey),
        ),
      ],
    );
  }

  Widget _buildLocationChip(String location) {
    return Chip(
      label: Text(location),
      backgroundColor: Colors.grey[200],
    );
  }
}