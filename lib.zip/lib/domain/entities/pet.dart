class Pet{

}